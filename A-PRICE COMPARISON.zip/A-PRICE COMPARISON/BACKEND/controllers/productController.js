// controllers/productController.js
const { fetchProducts } = require('../scraper/scraper');

exports.searchProducts = async (req, res) => {
    try {
        const { search } = req.query;
        if (!search) return res.status(400).json({ message: 'Search term is required' });

        const products = await fetchProducts(search);
        res.json(products);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
