import React, { useState } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';

const Home = () => {
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState([]);

  const handleSearch = async () => {
    if (!search) return;
    try {
      const res = await axios.get(`http://localhost:5000/api/products/search?search=${search}`);
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Search Products</h1>
      <input 
        type="text" 
        placeholder="Search..." 
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ padding: '10px', width: '300px' }}
      />
      <button onClick={handleSearch} style={{ padding: '10px', marginLeft: '10px' }}>
        Search
      </button>

      <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: '20px' }}>
        {products.map((product, idx) => (
          <ProductCard key={idx} product={product} />
        ))}
      </div>
    </div>
  );
};

export default Home;
