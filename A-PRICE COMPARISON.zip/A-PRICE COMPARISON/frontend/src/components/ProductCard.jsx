import React from 'react';

const ProductCard = ({ product }) => {
  return (
    <div style={{ border: '1px solid gray', margin: '10px', padding: '10px', width: '250px', textAlign: 'center' }}>
      <img src={product.image} alt={product.name} style={{ width: '150px' }} />
      <h3>{product.name}</h3>
      <p>Price: ₹{product.price}</p>
      <a href={product.link} target="_blank" rel="noopener noreferrer">
        <button style={{ padding: '10px', marginTop: '10px' }}>View Product</button>
      </a>
    </div>
  );
};

export default ProductCard;
